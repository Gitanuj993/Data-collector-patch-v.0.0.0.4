import LapList from '../LapList';
import type { Lap } from '@shared/schema';

export default function LapListExample() {
  const mockLaps: Lap[] = [
    { id: '1', name: 'Lap 1', time: 15430, lapNumber: 1 },
    { id: '2', name: 'Lap 2', time: 28950, lapNumber: 2 },
    { id: '3', name: 'Sprint Section', time: 42310, lapNumber: 3 },
  ];

  return (
    <div className="h-[400px] flex flex-col">
      <LapList
        laps={mockLaps}
        onRenameLap={(id, name) => console.log(`Rename lap ${id} to ${name}`)}
      />
    </div>
  );
}
