import TimerDisplay from '../TimerDisplay';

export default function TimerDisplayExample() {
  return <TimerDisplay time={125430} />;
}
