import ControlButtons from '../ControlButtons';

export default function ControlButtonsExample() {
  return (
    <ControlButtons
      isRunning={false}
      hasStarted={true}
      onStartStop={() => console.log('Start/Stop clicked')}
      onLap={() => console.log('Lap clicked')}
      onReset={() => console.log('Reset clicked')}
    />
  );
}
