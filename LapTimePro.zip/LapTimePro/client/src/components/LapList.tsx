import { useState } from "react";
import { Pencil, Timer } from "lucide-react";
import type { Lap } from "@shared/schema";

interface LapListProps {
  laps: Lap[];
  onRenameLap: (id: string, newName: string) => void;
}

export default function LapList({ laps, onRenameLap }: LapListProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");

  const formatTime = (ms: number) => {
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    const milliseconds = Math.floor((ms % 1000) / 10);
    
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}.${String(milliseconds).padStart(2, '0')}`;
  };

  const handleStartEdit = (lap: Lap) => {
    setEditingId(lap.id);
    setEditValue(lap.name);
  };

  const handleSave = (id: string) => {
    if (editValue.trim()) {
      onRenameLap(id, editValue.trim());
    }
    setEditingId(null);
    setEditValue("");
  };

  const handleKeyDown = (e: React.KeyboardEvent, id: string) => {
    if (e.key === "Enter") {
      handleSave(id);
    } else if (e.key === "Escape") {
      setEditingId(null);
      setEditValue("");
    }
  };

  if (laps.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center py-16 px-4">
        <Timer className="h-12 w-12 opacity-40 mb-4" />
        <p className="text-sm opacity-40" data-testid="text-empty-state">No laps recorded yet</p>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto border-t">
      <div className="max-h-[50vh] md:max-h-none">
        {laps.map((lap) => (
          <div
            key={lap.id}
            className="grid grid-cols-[auto_1fr_auto] gap-4 px-6 py-4 border-b hover-elevate"
            data-testid={`row-lap-${lap.id}`}
          >
            <div className="w-12 text-right text-sm opacity-60" data-testid={`text-lap-number-${lap.id}`}>
              #{lap.lapNumber}
            </div>
            
            <div className="flex items-center gap-2 min-w-0">
              {editingId === lap.id ? (
                <input
                  type="text"
                  value={editValue}
                  onChange={(e) => setEditValue(e.target.value)}
                  onBlur={() => handleSave(lap.id)}
                  onKeyDown={(e) => handleKeyDown(e, lap.id)}
                  className="flex-1 border-b-2 border-primary outline-none bg-transparent font-medium"
                  autoFocus
                  maxLength={30}
                  data-testid={`input-lap-name-${lap.id}`}
                />
              ) : (
                <button
                  onClick={() => handleStartEdit(lap)}
                  className="flex items-center gap-2 flex-1 text-left group min-w-0"
                  data-testid={`button-edit-lap-${lap.id}`}
                >
                  <span className="font-medium truncate" data-testid={`text-lap-name-${lap.id}`}>
                    {lap.name}
                  </span>
                  <Pencil className="h-3 w-3 opacity-0 group-hover:opacity-60 transition-opacity flex-shrink-0" />
                </button>
              )}
            </div>
            
            <div className="font-mono font-medium text-right" data-testid={`text-lap-time-${lap.id}`}>
              {formatTime(lap.time)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
