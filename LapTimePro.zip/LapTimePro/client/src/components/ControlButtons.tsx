import { Button } from "@/components/ui/button";
import { Play, Pause, RotateCcw, Circle } from "lucide-react";

interface ControlButtonsProps {
  isRunning: boolean;
  hasStarted: boolean;
  onStartStop: () => void;
  onLap: () => void;
  onReset: () => void;
}

export default function ControlButtons({
  isRunning,
  hasStarted,
  onStartStop,
  onLap,
  onReset,
}: ControlButtonsProps) {
  return (
    <div className="flex flex-col md:flex-row gap-4 justify-center items-center px-4 pb-6">
      <Button
        onClick={onStartStop}
        size="lg"
        className="rounded-full px-12 py-6 text-lg font-semibold min-w-[160px]"
        data-testid="button-start-stop"
      >
        {isRunning ? (
          <>
            <Pause className="mr-2 h-5 w-5" />
            Stop
          </>
        ) : (
          <>
            <Play className="mr-2 h-5 w-5" />
            Start
          </>
        )}
      </Button>

      <Button
        onClick={onLap}
        disabled={!isRunning}
        variant="secondary"
        size="lg"
        className="rounded-lg px-8 py-6 text-lg font-semibold min-w-[140px]"
        data-testid="button-lap"
      >
        <Circle className="mr-2 h-4 w-4" />
        Lap
      </Button>

      {!isRunning && hasStarted && (
        <Button
          onClick={onReset}
          variant="outline"
          size="lg"
          className="rounded-lg px-6 py-6 text-lg font-semibold"
          data-testid="button-reset"
        >
          <RotateCcw className="mr-2 h-4 w-4" />
          Reset
        </Button>
      )}
    </div>
  );
}
