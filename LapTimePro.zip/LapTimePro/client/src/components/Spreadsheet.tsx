import { useState, useRef, useEffect } from "react";
import { Input } from "@/components/ui/input";
import type { Cell, CellValue, SpreadsheetColumn } from "@shared/schema";

interface SpreadsheetProps {
  onDataChange?: (cells: Cell[]) => void;
  selectedDate?: number;
}

const getCellKey = (row: number, col: number) => `${row}-${col}`;

export default function Spreadsheet({ onDataChange, selectedDate = 0 }: SpreadsheetProps) {
  const [columns, setColumns] = useState<SpreadsheetColumn[]>(() => {
    const stored = localStorage.getItem("spreadsheet_columns");
    if (stored) {
      try {
        return JSON.parse(stored);
      } catch (e) {
        console.error("Failed to parse stored columns", e);
      }
    }
    return [
      { id: "1", name: "Topic 1" },
      { id: "2", name: "Topic 2" },
      { id: "3", name: "Topic 3" },
      { id: "4", name: "Topic 4" },
    ];
  });
  
  const [cells, setCells] = useState<Map<string, CellValue>>(() => {
    const stored = localStorage.getItem("spreadsheet_data");
    if (stored) {
      try {
        const cellsArray: Cell[] = JSON.parse(stored);
        const cellsMap = new Map<string, CellValue>();
        cellsArray.forEach(cell => {
          cellsMap.set(getCellKey(cell.row, cell.col), cell.value);
        });
        return cellsMap;
      } catch (e) {
        console.error("Failed to parse stored data", e);
      }
    }
    return new Map();
  });
  const [editingCell, setEditingCell] = useState<{ row: number; col: number } | null>(null);
  const [editValue, setEditValue] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editingCell && inputRef.current) {
      inputRef.current.focus();
    }
  }, [editingCell]);

  const getCellValue = (row: number, col: number): CellValue => {
    return cells.get(getCellKey(row, col)) ?? null;
  };

  const parseCellValue = (value: string): CellValue => {
    const trimmed = value.trim();
    
    if (trimmed === "" || trimmed === "-") return null;
    if (trimmed.toLowerCase() === "true") return true;
    if (trimmed.toLowerCase() === "false") return false;
    
    const num = parseFloat(trimmed);
    if (!isNaN(num)) return num;
    
    return null;
  };

  const formatCellValue = (value: CellValue): string => {
    if (value === null) return "-";
    if (typeof value === "boolean") return value ? "true" : "false";
    return value.toString();
  };

  const handleCellClick = (row: number, col: number) => {
    setEditingCell({ row, col });
    setEditValue(formatCellValue(getCellValue(row, col)));
  };

  const handleCellSave = () => {
    if (editingCell) {
      const newCells = new Map(cells);
      const parsedValue = parseCellValue(editValue);
      newCells.set(getCellKey(editingCell.row, editingCell.col), parsedValue);
      setCells(newCells);
      
      const cellsArray: Cell[] = Array.from(newCells.entries()).map(([key, value]) => {
        const [row, col] = key.split("-").map(Number);
        return { row, col, value };
      });
      
      localStorage.setItem("spreadsheet_data", JSON.stringify(cellsArray));
      localStorage.setItem("spreadsheet_columns", JSON.stringify(columns));
      
      if (onDataChange) {
        onDataChange(cellsArray);
      }
    }
    setEditingCell(null);
    setEditValue("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleCellSave();
    } else if (e.key === "Escape") {
      setEditingCell(null);
      setEditValue("");
    } else if (e.key === "Tab") {
      e.preventDefault();
      if (editingCell) {
        const newCells = new Map(cells);
        const parsedValue = parseCellValue(editValue);
        newCells.set(getCellKey(editingCell.row, editingCell.col), parsedValue);
        setCells(newCells);
        
        const cellsArray: Cell[] = Array.from(newCells.entries()).map(([key, value]) => {
          const [row, col] = key.split("-").map(Number);
          return { row, col, value };
        });
        
        localStorage.setItem("spreadsheet_data", JSON.stringify(cellsArray));
        
        if (e.shiftKey) {
          setEditingCell({ row: editingCell.row, col: Math.max(0, editingCell.col - 1) });
          setEditValue(formatCellValue(getCellValue(editingCell.row, Math.max(0, editingCell.col - 1))));
        } else {
          setEditingCell({ row: editingCell.row, col: editingCell.col + 1 });
          setEditValue(formatCellValue(getCellValue(editingCell.row, editingCell.col + 1)));
        }
      }
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      if (editingCell) {
        const newCells = new Map(cells);
        const parsedValue = parseCellValue(editValue);
        newCells.set(getCellKey(editingCell.row, editingCell.col), parsedValue);
        setCells(newCells);
        
        const cellsArray: Cell[] = Array.from(newCells.entries()).map(([key, value]) => {
          const [row, col] = key.split("-").map(Number);
          return { row, col, value };
        });
        
        localStorage.setItem("spreadsheet_data", JSON.stringify(cellsArray));
        
        const newRow = Math.max(0, editingCell.row - 1);
        setEditingCell({ row: newRow, col: editingCell.col });
        setEditValue(formatCellValue(getCellValue(newRow, editingCell.col)));
      }
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      if (editingCell) {
        const newCells = new Map(cells);
        const parsedValue = parseCellValue(editValue);
        newCells.set(getCellKey(editingCell.row, editingCell.col), parsedValue);
        setCells(newCells);
        
        const cellsArray: Cell[] = Array.from(newCells.entries()).map(([key, value]) => {
          const [row, col] = key.split("-").map(Number);
          return { row, col, value };
        });
        
        localStorage.setItem("spreadsheet_data", JSON.stringify(cellsArray));
        
        const newRow = Math.min(49, editingCell.row + 1);
        setEditingCell({ row: newRow, col: editingCell.col });
        setEditValue(formatCellValue(getCellValue(newRow, editingCell.col)));
      }
    } else if (e.key === "ArrowLeft") {
      e.preventDefault();
      if (editingCell) {
        const newCells = new Map(cells);
        const parsedValue = parseCellValue(editValue);
        newCells.set(getCellKey(editingCell.row, editingCell.col), parsedValue);
        setCells(newCells);
        
        const cellsArray: Cell[] = Array.from(newCells.entries()).map(([key, value]) => {
          const [row, col] = key.split("-").map(Number);
          return { row, col, value };
        });
        
        localStorage.setItem("spreadsheet_data", JSON.stringify(cellsArray));
        
        const newCol = Math.max(0, editingCell.col - 1);
        setEditingCell({ row: editingCell.row, col: newCol });
        setEditValue(formatCellValue(getCellValue(editingCell.row, newCol)));
      }
    } else if (e.key === "ArrowRight") {
      e.preventDefault();
      if (editingCell) {
        const newCells = new Map(cells);
        const parsedValue = parseCellValue(editValue);
        newCells.set(getCellKey(editingCell.row, editingCell.col), parsedValue);
        setCells(newCells);
        
        const cellsArray: Cell[] = Array.from(newCells.entries()).map(([key, value]) => {
          const [row, col] = key.split("-").map(Number);
          return { row, col, value };
        });
        
        localStorage.setItem("spreadsheet_data", JSON.stringify(cellsArray));
        
        setEditingCell({ row: editingCell.row, col: editingCell.col + 1 });
        setEditValue(formatCellValue(getCellValue(editingCell.row, editingCell.col + 1)));
      }
    }
  };

  return (
    <div className="relative h-full overflow-auto">
      <table className="w-full border-collapse" data-testid="spreadsheet-table" style={{ borderSpacing: 0 }}>
        <thead className="sticky top-0 z-20 bg-card">
          <tr>
            <th className="sticky left-0 z-30 bg-card border px-4 py-2 text-left font-medium text-sm w-20">
              Date
            </th>
            {columns.map((col, colIndex) => (
              <th
                key={col.id}
                className="border px-4 py-2 text-left font-medium text-sm min-w-[120px]"
                data-testid={`header-col-${colIndex}`}
              >
                <Input
                  value={col.name}
                  onChange={(e) => {
                    const newColumns = [...columns];
                    newColumns[colIndex].name = e.target.value;
                    setColumns(newColumns);
                  }}
                  className="h-7 border-0 bg-transparent p-0 focus-visible:ring-0"
                  data-testid={`input-header-${colIndex}`}
                />
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {Array.from({ length: 50 }, (_, rowIndex) => {
            const date = selectedDate + rowIndex + 1;
            return (
              <tr key={rowIndex} data-testid={`row-${rowIndex}`}>
                <td className="sticky left-0 z-10 bg-card border px-4 py-2 text-sm font-medium w-20">
                  {date}
                </td>
                {columns.map((_, colIndex) => {
                  const isEditing =
                    editingCell?.row === rowIndex && editingCell?.col === colIndex;
                  const cellValue = getCellValue(rowIndex, colIndex);

                  return (
                    <td
                      key={colIndex}
                      className="border px-2 py-1"
                      data-testid={`cell-${rowIndex}-${colIndex}`}
                    >
                      {isEditing ? (
                        <Input
                          ref={inputRef}
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          onBlur={handleCellSave}
                          onKeyDown={handleKeyDown}
                          className="h-8 border-primary border-2"
                          data-testid={`input-cell-${rowIndex}-${colIndex}`}
                        />
                      ) : (
                        <div
                          onClick={() => handleCellClick(rowIndex, colIndex)}
                          className="h-8 flex items-center px-2 cursor-pointer hover-elevate rounded"
                          data-testid={`cell-value-${rowIndex}-${colIndex}`}
                        >
                          <span className={cellValue === null ? "text-muted-foreground" : ""}>
                            {formatCellValue(cellValue)}
                          </span>
                        </div>
                      )}
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
