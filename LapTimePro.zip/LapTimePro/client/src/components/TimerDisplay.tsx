interface TimerDisplayProps {
  time: number;
}

export default function TimerDisplay({ time }: TimerDisplayProps) {
  const formatTime = (ms: number) => {
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    const milliseconds = Math.floor((ms % 1000) / 10);
    
    return {
      minutes: String(minutes).padStart(2, '0'),
      seconds: String(seconds).padStart(2, '0'),
      milliseconds: String(milliseconds).padStart(2, '0')
    };
  };

  const { minutes, seconds, milliseconds } = formatTime(time);

  return (
    <div className="flex items-center justify-center py-12 min-h-[200px]">
      <time className="font-mono text-6xl md:text-7xl lg:text-8xl font-light" data-testid="text-timer-display">
        {minutes}:{seconds}
        <span className="opacity-60 text-5xl md:text-6xl lg:text-7xl">.{milliseconds}</span>
      </time>
    </div>
  );
}
