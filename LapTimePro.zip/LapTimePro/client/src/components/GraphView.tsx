import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { Cell } from "@shared/schema";

interface GraphViewProps {
  data: Cell[];
  columnNames?: string[];
}

export default function GraphView({ data, columnNames = [] }: GraphViewProps) {
  // Transform cell data to create separate chart data for each column
  const getChartDataByColumn = () => {
    if (data.length === 0) return new Map<number, any[]>();

    // Find all columns that have numeric data
    const columnMap = new Map<number, Map<number, number>>();

    data.forEach(cell => {
      if (typeof cell.value === "number") {
        if (!columnMap.has(cell.col)) {
          columnMap.set(cell.col, new Map());
        }
        columnMap.get(cell.col)!.set(cell.row, cell.value);
      }
    });

    // Convert to chart format for each column
    const chartsByColumn = new Map<number, any[]>();

    columnMap.forEach((rowMap, colIndex) => {
      const chartData = Array.from(rowMap.entries())
        .sort(([rowA], [rowB]) => rowA - rowB)
        .map(([row, value]) => ({
          row: `Row ${row + 1}`,
          value: value,
        }));
      chartsByColumn.set(colIndex, chartData);
    });

    return chartsByColumn;
  };

  const chartsByColumn = getChartDataByColumn();
  const hasData = chartsByColumn.size > 0;

  if (!hasData) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <p className="text-muted-foreground" data-testid="text-no-data">
            No numeric data to display
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            Enter numbers in the spreadsheet to see graphs
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-8">
      <Tabs defaultValue="line" className="w-full" data-testid="tabs-graph-view">
        <TabsList data-testid="tabs-graph-types">
          <TabsTrigger value="line" data-testid="tab-line">
            Line Chart
          </TabsTrigger>
          <TabsTrigger value="bar" data-testid="tab-bar">
            Bar Chart
          </TabsTrigger>
        </TabsList>

        <TabsContent value="line" className="mt-6 space-y-6">
          {Array.from(chartsByColumn.entries()).map(([colIndex, chartData]) => (
            <Card key={colIndex} data-testid={`card-line-chart-${colIndex}`}>
              <CardHeader>
                <CardTitle>
                  {columnNames[colIndex] || `Column ${colIndex + 1}`}
                </CardTitle>
                <CardDescription>
                  Values by row for {columnNames[colIndex] || `Column ${colIndex + 1}`}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="row" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="value"
                      stroke="hsl(217, 91%, 50%)"
                      name="Value"
                      dot={{ r: 4 }}
                      data-testid={`line-${colIndex}`}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="bar" className="mt-6 space-y-6">
          {Array.from(chartsByColumn.entries()).map(([colIndex, chartData]) => (
            <Card key={colIndex} data-testid={`card-bar-chart-${colIndex}`}>
              <CardHeader>
                <CardTitle>
                  {columnNames[colIndex] || `Column ${colIndex + 1}`}
                </CardTitle>
                <CardDescription>
                  Values by row for {columnNames[colIndex] || `Column ${colIndex + 1}`}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="row" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar
                      dataKey="value"
                      fill="hsl(217, 91%, 50%)"
                      name="Value"
                      data-testid={`bar-${colIndex}`}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}
