import { useState, useEffect, useRef } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";
import { Table2, LineChart, Timer, Play, Pause, RotateCcw, Circle, Pencil, MoreVertical } from "lucide-react";
import type { Lap } from "@shared/schema";

interface NavbarProps {
  onDateChange?: (date: number) => void;
}

const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

export default function Navbar({ onDateChange }: NavbarProps) {
  const [location] = useLocation();
  const [time, setTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [isStopwatchOpen, setIsStopwatchOpen] = useState(false);
  const [laps, setLaps] = useState<Lap[]>([]);
  const [editingLapId, setEditingLapId] = useState<string | null>(null);
  const [editLapValue, setEditLapValue] = useState("");
  const [selectedDate, setSelectedDate] = useState(0);
  const [selectedMonth, setSelectedMonth] = useState(0);
  const [selectedYear, setSelectedYear] = useState(2024);
  const startTimeRef = useRef<number>(0);
  const animationFrameRef = useRef<number>();

  useEffect(() => {
    if (isRunning) {
      startTimeRef.current = Date.now() - time;
      
      const updateTimer = () => {
        setTime(Date.now() - startTimeRef.current);
        animationFrameRef.current = requestAnimationFrame(updateTimer);
      };
      
      animationFrameRef.current = requestAnimationFrame(updateTimer);
    } else {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isRunning, time]);

  const formatTime = (ms: number) => {
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    const milliseconds = Math.floor((ms % 1000) / 10);
    
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}.${String(milliseconds).padStart(2, '0')}`;
  };

  const handleStartStop = () => {
    setIsRunning(!isRunning);
  };

  const handleLap = () => {
    if (isRunning) {
      const newLap: Lap = {
        id: crypto.randomUUID(),
        name: `Lap ${laps.length + 1}`,
        time: time,
        lapNumber: laps.length + 1,
      };
      setLaps([newLap, ...laps]);
    }
  };

  const handleReset = () => {
    setTime(0);
    setLaps([]);
    setIsRunning(false);
  };

  const handleRenameLap = (id: string, newName: string) => {
    setLaps(laps.map(lap => 
      lap.id === id ? { ...lap, name: newName } : lap
    ));
    setEditingLapId(null);
    setEditLapValue("");
  };

  const handleDateChange = (newDate: number) => {
    setSelectedDate(newDate);
    if (onDateChange) {
      onDateChange(newDate);
    }
  };

  const handleMonthYearChange = (month: number, year: number) => {
    setSelectedMonth(month);
    setSelectedYear(year);
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const dateOffset = selectedMonth * 30 + (year - 2024) * 365;
    handleDateChange(dateOffset);
  };

  return (
    <nav className="border-b bg-card">
      <div className="flex items-center justify-between px-6 py-3">
        <div className="flex items-center gap-6">
          <h1 className="text-xl font-semibold">Data Tracker</h1>
          
          <div className="flex gap-1">
            <Link href="/">
              <Button
                variant={location === "/" ? "secondary" : "ghost"}
                size="sm"
                data-testid="link-spreadsheet"
              >
                <Table2 className="h-4 w-4 mr-2" />
                Spreadsheet
              </Button>
            </Link>
            
            <Link href="/graphs">
              <Button
                variant={location === "/graphs" ? "secondary" : "ghost"}
                size="sm"
                data-testid="link-graphs"
              >
                <LineChart className="h-4 w-4 mr-2" />
                Graphs
              </Button>
            </Link>
          </div>

          {location === "/" && (
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="ml-2"
                  data-testid="button-date-menu"
                >
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80" align="start" data-testid="popover-date-picker">
                <div className="space-y-4">
                  <h3 className="text-sm font-medium">Select Month and Year</h3>
                  
                  <div className="space-y-2">
                    <label className="text-xs font-medium text-muted-foreground">Month</label>
                    <select
                      value={selectedMonth}
                      onChange={(e) => handleMonthYearChange(parseInt(e.target.value), selectedYear)}
                      className="w-full border rounded px-3 py-2 text-sm bg-background"
                      data-testid="select-month"
                    >
                      {MONTHS.map((month, idx) => (
                        <option key={idx} value={idx}>
                          {month}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-medium text-muted-foreground">Year</label>
                    <select
                      value={selectedYear}
                      onChange={(e) => handleMonthYearChange(selectedMonth, parseInt(e.target.value))}
                      className="w-full border rounded px-3 py-2 text-sm bg-background"
                      data-testid="select-year"
                    >
                      {Array.from({ length: 10 }, (_, i) => 2020 + i).map((year) => (
                        <option key={year} value={year}>
                          {year}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="text-xs text-muted-foreground pt-2">
                    {MONTHS[selectedMonth]} {selectedYear}
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          )}
        </div>

        <Sheet open={isStopwatchOpen} onOpenChange={setIsStopwatchOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="sm" data-testid="button-open-stopwatch">
              <Timer className="h-4 w-4 mr-2" />
              {formatTime(time)}
            </Button>
          </SheetTrigger>
          <SheetContent side="right" data-testid="stopwatch-panel">
            <SheetTitle className="text-2xl font-semibold">Stopwatch</SheetTitle>
            <div className="flex flex-col gap-6 mt-8 h-full">
              
              <div className="flex items-center justify-center py-8">
                <time className="font-mono text-5xl font-light" data-testid="text-stopwatch-time">
                  {formatTime(time)}
                </time>
              </div>

              <div className="flex flex-col gap-3">
                <Button
                  onClick={handleStartStop}
                  size="lg"
                  className="w-full"
                  data-testid="button-stopwatch-start-stop"
                >
                  {isRunning ? (
                    <>
                      <Pause className="mr-2 h-5 w-5" />
                      Stop
                    </>
                  ) : (
                    <>
                      <Play className="mr-2 h-5 w-5" />
                      Start
                    </>
                  )}
                </Button>

                <Button
                  onClick={handleLap}
                  disabled={!isRunning}
                  variant="secondary"
                  size="lg"
                  className="w-full"
                  data-testid="button-stopwatch-lap"
                >
                  <Circle className="mr-2 h-4 w-4" />
                  Lap
                </Button>

                {!isRunning && time > 0 && (
                  <Button
                    onClick={handleReset}
                    variant="outline"
                    size="lg"
                    className="w-full"
                    data-testid="button-stopwatch-reset"
                  >
                    <RotateCcw className="mr-2 h-4 w-4" />
                    Reset
                  </Button>
                )}
              </div>

              {laps.length > 0 && (
                <div className="flex-1 border-t pt-4">
                  <h3 className="text-sm font-medium mb-3">Laps</h3>
                  <ScrollArea className="h-[300px] pr-4">
                    <div className="space-y-2">
                      {laps.map((lap) => (
                        <div
                          key={lap.id}
                          className="flex items-center justify-between p-2 rounded border hover:bg-muted/50"
                          data-testid={`lap-item-${lap.id}`}
                        >
                          <div className="flex-1">
                            {editingLapId === lap.id ? (
                              <input
                                type="text"
                                value={editLapValue}
                                onChange={(e) => setEditLapValue(e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === "Enter") {
                                    handleRenameLap(lap.id, editLapValue);
                                  } else if (e.key === "Escape") {
                                    setEditingLapId(null);
                                  }
                                }}
                                onBlur={() => handleRenameLap(lap.id, editLapValue)}
                                className="w-full border-b text-sm"
                                autoFocus
                                data-testid={`input-lap-${lap.id}`}
                              />
                            ) : (
                              <button
                                onClick={() => {
                                  setEditingLapId(lap.id);
                                  setEditLapValue(lap.name);
                                }}
                                className="text-sm font-medium hover:text-primary flex items-center gap-1"
                                data-testid={`button-edit-lap-${lap.id}`}
                              >
                                {lap.name}
                                <Pencil className="h-3 w-3 opacity-0 hover:opacity-60" />
                              </button>
                            )}
                          </div>
                          <span className="font-mono text-xs ml-2">{formatTime(lap.time)}</span>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
              )}
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </nav>
  );
}
