import { useState, useEffect } from "react";
import Navbar from "@/components/Navbar";
import GraphView from "@/components/GraphView";
import type { Cell, SpreadsheetColumn } from "@shared/schema";

export default function GraphsPage() {
  const [spreadsheetData, setSpreadsheetData] = useState<Cell[]>([]);
  const [columns, setColumns] = useState<SpreadsheetColumn[]>([]);

  // Load data and columns from localStorage
  useEffect(() => {
    const storedData = localStorage.getItem("spreadsheet_data");
    if (storedData) {
      try {
        setSpreadsheetData(JSON.parse(storedData));
      } catch (e) {
        console.error("Failed to parse stored data", e);
      }
    }

    const storedColumns = localStorage.getItem("spreadsheet_columns");
    if (storedColumns) {
      try {
        setColumns(JSON.parse(storedColumns));
      } catch (e) {
        console.error("Failed to parse stored columns", e);
      }
    }
  }, []);

  const columnNames = columns.map(col => col.name);

  return (
    <div className="h-screen flex flex-col">
      <Navbar />
      <div className="flex-1 overflow-auto">
        <GraphView data={spreadsheetData} columnNames={columnNames} />
      </div>
    </div>
  );
}
