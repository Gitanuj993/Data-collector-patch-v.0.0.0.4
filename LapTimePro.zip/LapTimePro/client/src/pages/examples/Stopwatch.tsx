import Stopwatch from '../Stopwatch';

export default function StopwatchExample() {
  return <Stopwatch />;
}
