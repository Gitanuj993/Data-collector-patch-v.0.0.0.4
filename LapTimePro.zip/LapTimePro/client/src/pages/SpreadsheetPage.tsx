import { useState } from "react";
import Navbar from "@/components/Navbar";
import Spreadsheet from "@/components/Spreadsheet";
import type { Cell } from "@shared/schema";

export default function SpreadsheetPage() {
  const [spreadsheetData, setSpreadsheetData] = useState<Cell[]>([]);
  const [selectedDate, setSelectedDate] = useState(0);

  return (
    <div className="h-screen flex flex-col">
      <Navbar onDateChange={setSelectedDate} />
      <div className="flex-1 overflow-hidden">
        <Spreadsheet onDataChange={setSpreadsheetData} selectedDate={selectedDate} />
      </div>
    </div>
  );
}
