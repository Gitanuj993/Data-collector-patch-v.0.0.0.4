import { useState, useEffect, useRef } from "react";
import TimerDisplay from "@/components/TimerDisplay";
import ControlButtons from "@/components/ControlButtons";
import LapList from "@/components/LapList";
import type { Lap } from "@shared/schema";

export default function Stopwatch() {
  const [time, setTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [laps, setLaps] = useState<Lap[]>([]);
  const startTimeRef = useRef<number>(0);
  const animationFrameRef = useRef<number>();

  useEffect(() => {
    if (isRunning) {
      startTimeRef.current = Date.now() - time;
      
      const updateTimer = () => {
        setTime(Date.now() - startTimeRef.current);
        animationFrameRef.current = requestAnimationFrame(updateTimer);
      };
      
      animationFrameRef.current = requestAnimationFrame(updateTimer);
    } else {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isRunning, time]);

  const handleStartStop = () => {
    setIsRunning(!isRunning);
  };

  const handleLap = () => {
    if (isRunning) {
      const newLap: Lap = {
        id: crypto.randomUUID(),
        name: `Lap ${laps.length + 1}`,
        time: time,
        lapNumber: laps.length + 1,
      };
      setLaps([newLap, ...laps]);
    }
  };

  const handleReset = () => {
    setTime(0);
    setLaps([]);
    setIsRunning(false);
  };

  const handleRenameLap = (id: string, newName: string) => {
    setLaps(laps.map(lap => 
      lap.id === id ? { ...lap, name: newName } : lap
    ));
  };

  return (
    <div className="min-h-screen flex flex-col max-w-2xl mx-auto">
      <div className="flex-shrink-0">
        <TimerDisplay time={time} />
        <ControlButtons
          isRunning={isRunning}
          hasStarted={time > 0 || laps.length > 0}
          onStartStop={handleStartStop}
          onLap={handleLap}
          onReset={handleReset}
        />
      </div>
      <LapList laps={laps} onRenameLap={handleRenameLap} />
    </div>
  );
}
